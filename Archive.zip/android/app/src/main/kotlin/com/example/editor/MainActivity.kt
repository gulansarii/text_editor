package com.example.editor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
